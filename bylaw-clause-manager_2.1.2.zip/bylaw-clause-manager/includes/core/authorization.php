<?php

/** File: includes/core/authorization.php
 * Text Domain: bylaw-clause-manager
 * @version 2.1.2
 * @author greghacke
 * Function: Select authorization functionality for the plugin using core functions or accessSchema-client
 */

defined( 'ABSPATH' ) || exit;