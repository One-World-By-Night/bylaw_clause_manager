<?php

/** File: includes/languages/_template.php
 * Text Domain: bylaw-clause-manager
 * @version 2.3.0
 * @author greghacke
 * Function: 
 */

defined('ABSPATH') || exit;
