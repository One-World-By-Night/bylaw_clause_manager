<?php

/** File: includes/languages/init.php
 * Text Domain: bylaw-clause-manager
 * @version 2.2.3
 * @author greghacke
 * Function: Init languages functionality for the plugin
 */

defined( 'ABSPATH' ) || exit;

/** --- Require each language file once --- */
// require_once __DIR__ . '/_template.php';
