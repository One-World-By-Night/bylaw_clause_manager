<?php

/** File: includes/tests/util.php
 * Text Domain: bylaw-clause-manager
 * @version 2.2.4
 * @author greghacke
 * Function: 
 */

defined( 'ABSPATH' ) || exit;