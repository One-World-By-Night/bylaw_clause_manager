<?php

/** File: includes/tests/core.php
 * Text Domain: bylaw-clause-manager
 * @version 2.2.3
 * @author greghacke
 * Function: 
 */

defined( 'ABSPATH' ) || exit;