<?php

/** File: includes/tests/util.php
 * Text Domain: bylaw-clause-manager
 * @version 2.1.0
 * @author greghacke
 * Function: 
 */

defined( 'ABSPATH' ) || exit;