<?php

/** File: includes/tests/core.php
 * Text Domain: bylaw-clause-manager
 * @version 2.1.0
 * @author greghacke
 * Function: 
 */

defined( 'ABSPATH' ) || exit;