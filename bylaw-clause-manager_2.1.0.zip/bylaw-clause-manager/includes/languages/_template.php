<?php

/** File: includes/languages/_template.php
 * Text Domain: bylaw-clause-manager
 * @version 2.1.0
 * @author greghacke
 * Function: 
 */

defined( 'ABSPATH' ) || exit;