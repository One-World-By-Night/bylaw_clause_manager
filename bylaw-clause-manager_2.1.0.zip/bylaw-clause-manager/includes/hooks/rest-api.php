<?php

/** File: includes/hooks/rest-api.php
 * Text Domain: bylaw-clause-manager
 * @version 2.1.0
 * @author greghacke
 * Function: rest api framework for the Bylaw Clause Manager plugin
 */

defined( 'ABSPATH' ) || exit;