<?php

/** File: includes/hooks/webhooks.php
 * Text Domain: bylaw-clause-manager
 * @version 2.1.0
 * @author greghacke
 * Function: Uses the rest api framework to register webhooks for the Bylaw Clause Manager plugin
 */

defined( 'ABSPATH' ) || exit;