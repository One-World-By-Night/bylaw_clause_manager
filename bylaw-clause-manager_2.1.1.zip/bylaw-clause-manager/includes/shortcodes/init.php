<?php

/** File: includes/shortcode/init.php
 * Text Domain: bylaw-clause-manager
 * @version 2.1.1
 * @author greghacke
 * Function: Init shortcode functionality for the plugin
 */

defined( 'ABSPATH' ) || exit;

/** --- Require each shortcode file once --- */
require_once __DIR__ . '/listing.php';