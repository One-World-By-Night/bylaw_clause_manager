<?php

/** File: includes/tests/util.php
 * Text Domain: bylaw-clause-manager
 * @version 2.1.1
 * @author greghacke
 * Function: 
 */

defined( 'ABSPATH' ) || exit;