<?php

/** File: includes/tests/core.php
 * Text Domain: bylaw-clause-manager
 * @version 2.2.4
 * @author greghacke
 * Function: 
 */

defined( 'ABSPATH' ) || exit;