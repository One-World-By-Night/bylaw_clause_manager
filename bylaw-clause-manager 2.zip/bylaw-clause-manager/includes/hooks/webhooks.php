<?php

/** File: includes/hooks/webhooks.php
 * Text Domain: bylaw-clause-manager
 * @version 2.2.4
 * @author greghacke
 * Function: Uses the rest api framework to register webhooks for the Bylaw Clause Manager plugin
 */

defined( 'ABSPATH' ) || exit;