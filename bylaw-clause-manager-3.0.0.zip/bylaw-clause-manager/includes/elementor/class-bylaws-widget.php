<?php

/**
 * Bylaws Widget
 *
 * Elementor widget for displaying bylaw clause tree with filtering.
 *
 * location: includes/elementor/class-bylaws-widget.php
 * @package Bylaw-Clause-Manager
 */

defined('ABSPATH') || exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class BCM_Bylaws_Widget extends Widget_Base
{
	public function get_name(): string
	{
		return 'bcm_bylaws';
	}

	public function get_title(): string
	{
		return __('Bylaws', 'bylaw-clause-manager');
	}

	public function get_icon(): string
	{
		return 'eicon-document-file';
	}

	public function get_categories(): array
	{
		return ['owbn-bylaws'];
	}

	public function get_keywords(): array
	{
		return ['bylaws', 'clauses', 'owbn', 'hierarchy', 'rules'];
	}

	public function get_style_depends(): array
	{
		return ['bcm-widget'];
	}

	public function get_script_depends(): array
	{
		return ['bcm-filter'];
	}

	protected function register_controls(): void
	{
		// ===== CONTENT TAB =====
		$this->start_controls_section(
			'content_section',
			[
				'label' => __('Content', 'bylaw-clause-manager'),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		// Bylaw Group selector
		$groups = bcm_get_bylaw_groups();
		$group_options = ['all' => __('All Groups', 'bylaw-clause-manager')];
		foreach ($groups as $slug => $label) {
			$group_options[$slug] = $label;
		}

		$this->add_control(
			'bylaw_group',
			[
				'label'   => __('Bylaw Group', 'bylaw-clause-manager'),
				'type'    => Controls_Manager::SELECT,
				'options' => $group_options,
				'default' => 'all',
			]
		);

		$this->add_control(
			'show_filters',
			[
				'label'        => __('Show Filter Toolbar', 'bylaw-clause-manager'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __('Show', 'bylaw-clause-manager'),
				'label_off'    => __('Hide', 'bylaw-clause-manager'),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_print',
			[
				'label'        => __('Show Print Button', 'bylaw-clause-manager'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __('Show', 'bylaw-clause-manager'),
				'label_off'    => __('Hide', 'bylaw-clause-manager'),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'show_filters' => 'yes',
				],
			]
		);

		$this->add_control(
			'show_updated',
			[
				'label'        => __('Show Last Updated Date', 'bylaw-clause-manager'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __('Show', 'bylaw-clause-manager'),
				'label_off'    => __('Hide', 'bylaw-clause-manager'),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'max_depth',
			[
				'label'       => __('Max Display Depth', 'bylaw-clause-manager'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 10,
				'step'        => 1,
				'default'     => 0,
				'description' => __('0 = unlimited depth', 'bylaw-clause-manager'),
			]
		);

		$this->add_control(
			'show_vote_tooltips',
			[
				'label'        => __('Show Vote Tooltips', 'bylaw-clause-manager'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __('Show', 'bylaw-clause-manager'),
				'label_off'    => __('Hide', 'bylaw-clause-manager'),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->end_controls_section();

		// ===== STYLE TAB =====

		// Section ID Typography
		$this->start_controls_section(
			'style_section_id',
			[
				'label' => __('Section ID', 'bylaw-clause-manager'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'section_id_color',
			[
				'label'     => __('Color', 'bylaw-clause-manager'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bylaw-section-id' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'section_id_typography',
				'selector' => '{{WRAPPER}} .bylaw-section-id',
			]
		);

		$this->end_controls_section();

		// Clause Content Typography
		$this->start_controls_section(
			'style_clause_content',
			[
				'label' => __('Clause Content', 'bylaw-clause-manager'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'clause_color',
			[
				'label'     => __('Text Color', 'bylaw-clause-manager'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bylaw-label-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'clause_typography',
				'selector' => '{{WRAPPER}} .bylaw-label-text',
			]
		);

		$this->add_responsive_control(
			'clause_spacing',
			[
				'label'      => __('Clause Spacing', 'bylaw-clause-manager'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', 'em'],
				'range'      => [
					'px' => ['min' => 0, 'max' => 100],
					'em' => ['min' => 0, 'max' => 10, 'step' => 0.1],
				],
				'default'    => ['unit' => 'em', 'size' => 1],
				'selectors'  => [
					'{{WRAPPER}} .bylaw-clause' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Indentation
		$this->start_controls_section(
			'style_indentation',
			[
				'label' => __('Hierarchy Indentation', 'bylaw-clause-manager'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'indent_per_level',
			[
				'label'       => __('Indent Per Level', 'bylaw-clause-manager'),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => ['px'],
				'range'       => [
					'px' => ['min' => 0, 'max' => 100],
				],
				'default'     => ['unit' => 'px', 'size' => 20],
				'description' => __('Indentation applied to each nested level', 'bylaw-clause-manager'),
			]
		);

		$this->end_controls_section();

		// Search Highlighting
		$this->start_controls_section(
			'style_highlighting',
			[
				'label' => __('Search Highlighting', 'bylaw-clause-manager'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'highlight_bg',
			[
				'label'     => __('Background Color', 'bylaw-clause-manager'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffeb3b',
				'selectors' => [
					'{{WRAPPER}} .bcm-highlight' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'highlight_text',
			[
				'label'     => __('Text Color', 'bylaw-clause-manager'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000',
				'selectors' => [
					'{{WRAPPER}} .bcm-highlight' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'highlight_radius',
			[
				'label'      => __('Border Radius', 'bylaw-clause-manager'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => ['min' => 0, 'max' => 20],
				],
				'default'    => ['unit' => 'px', 'size' => 3],
				'selectors'  => [
					'{{WRAPPER}} .bcm-highlight' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Vote Tooltips
		$this->start_controls_section(
			'style_tooltips',
			[
				'label'     => __('Vote Tooltips', 'bylaw-clause-manager'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_vote_tooltips' => 'yes',
				],
			]
		);

		$this->add_control(
			'tooltip_bg',
			[
				'label'     => __('Background Color', 'bylaw-clause-manager'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#333',
				'selectors' => [
					'{{WRAPPER}} .vote-tooltip .tooltip-content' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'tooltip_text',
			[
				'label'     => __('Text Color', 'bylaw-clause-manager'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'{{WRAPPER}} .vote-tooltip .tooltip-content' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'tooltip_trigger_color',
			[
				'label'     => __('Trigger Text Color', 'bylaw-clause-manager'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#555',
				'selectors' => [
					'{{WRAPPER}} .vote-tooltip' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'tooltip_typography',
				'selector' => '{{WRAPPER}} .vote-tooltip .tooltip-content',
			]
		);

		$this->end_controls_section();

		// Toolbar Styling
		$this->start_controls_section(
			'style_toolbar',
			[
				'label'     => __('Filter Toolbar', 'bylaw-clause-manager'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_filters' => 'yes',
				],
			]
		);

		$this->add_control(
			'toolbar_bg',
			[
				'label'     => __('Background Color', 'bylaw-clause-manager'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #bcm-toolbar' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'toolbar_padding',
			[
				'label'      => __('Padding', 'bylaw-clause-manager'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em'],
				'selectors'  => [
					'{{WRAPPER}} #bcm-toolbar' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'toolbar_margin',
			[
				'label'      => __('Margin', 'bylaw-clause-manager'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em'],
				'selectors'  => [
					'{{WRAPPER}} #bcm-toolbar' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'heading_toolbar_input',
			[
				'label'     => __('Search Input', 'bylaw-clause-manager'),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'toolbar_input_bg',
			[
				'label'     => __('Background Color', 'bylaw-clause-manager'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #bcm-content-filter' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'toolbar_input_border',
			[
				'label'     => __('Border Color', 'bylaw-clause-manager'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #bcm-content-filter' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'toolbar_input_radius',
			[
				'label'      => __('Border Radius', 'bylaw-clause-manager'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => ['min' => 0, 'max' => 50],
				],
				'selectors'  => [
					'{{WRAPPER}} #bcm-content-filter' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'heading_toolbar_buttons',
			[
				'label'     => __('Buttons', 'bylaw-clause-manager'),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'toolbar_button_bg',
			[
				'label'     => __('Background Color', 'bylaw-clause-manager'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #bcm-toolbar button' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'toolbar_button_text',
			[
				'label'     => __('Text Color', 'bylaw-clause-manager'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #bcm-toolbar button' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'toolbar_button_hover_bg',
			[
				'label'     => __('Hover Background', 'bylaw-clause-manager'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #bcm-toolbar button:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'toolbar_button_typography',
				'selector' => '{{WRAPPER}} #bcm-toolbar button',
			]
		);

		$this->end_controls_section();

		// Updated Date Styling
		$this->start_controls_section(
			'style_updated',
			[
				'label'     => __('Last Updated Date', 'bylaw-clause-manager'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_updated' => 'yes',
				],
			]
		);

		$this->add_control(
			'updated_color',
			[
				'label'     => __('Text Color', 'bylaw-clause-manager'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bcm-updated' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'updated_typography',
				'selector' => '{{WRAPPER}} .bcm-updated',
			]
		);

		$this->add_responsive_control(
			'updated_margin',
			[
				'label'      => __('Margin', 'bylaw-clause-manager'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em'],
				'selectors'  => [
					'{{WRAPPER}} .bcm-updated' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render(): void
	{
		$settings = $this->get_settings_for_display();

		// Get settings
		$group = ($settings['bylaw_group'] ?? 'all') === 'all' ? null : $settings['bylaw_group'];
		$show_filters = ($settings['show_filters'] ?? 'yes') === 'yes';
		$show_print = ($settings['show_print'] ?? 'yes') === 'yes';
		$show_updated = ($settings['show_updated'] ?? 'yes') === 'yes';
		$show_tooltips = ($settings['show_vote_tooltips'] ?? 'yes') === 'yes';
		$max_depth = absint($settings['max_depth'] ?? 0);
		$indent = absint($settings['indent_per_level']['size'] ?? 20);

		// ===== CACHE CHECK START =====
		$use_cache = !current_user_can('edit_posts') && !\Elementor\Plugin::$instance->editor->is_edit_mode();
		$cache_version = get_option('bcm_cache_version', 0);
		$cache_key = 'bcm_bylaws_widget_' . md5(serialize($settings) . $cache_version);

		if ($use_cache && ($cached = get_transient($cache_key))) {
			echo $cached;
			return;
		}
		// ===== CACHE CHECK END =====

		ob_start();

		// Query latest modified clause for timestamp
		if ($show_updated) {
			$args = [
				'post_type'      => 'bylaw_clause',
				'posts_per_page' => 1,
				'orderby'        => 'modified',
				'order'          => 'DESC',
				'post_status'    => 'any',
				'fields'         => 'ids',
			];

			if ($group) {
				$args['meta_query'] = [[
					'key'     => 'bylaw_group',
					'value'   => $group,
					'compare' => '='
				]];
			}

			$latest = get_posts($args);
			$latest_time = $latest ? get_post_modified_time('F j, Y', false, $latest[0]) : '';

			if ($latest_time) {
				echo '<div class="bcm-updated"><strong>' . esc_html__('Last Updated:', 'bylaw-clause-manager') . ' ' . esc_html($latest_time) . '</strong></div>';
			}
		}

		// Render toolbar
		if ($show_filters) {
			echo '<div id="bcm-toolbar"><!-- #bcm-toolbar -->';
			echo '  <label for="bcm-content-filter">' . esc_html__('Filter by Content:', 'bylaw-clause-manager') . '</label>';
			echo '  <input type="text" id="bcm-content-filter" placeholder="' . esc_attr__('Press Enter or click Search...', 'bylaw-clause-manager') . '" style="width: 300px;" />';
			echo '  <button type="button" id="bcm-content-search">' . esc_html__('Search', 'bylaw-clause-manager') . '</button>';
			echo '  <button type="button" onclick="bcmClearFilters()">' . esc_html__('Clear Filters', 'bylaw-clause-manager') . '</button>';
			if ($show_print) {
				echo '  <button type="button" onclick="window.print()">' . esc_html__('Print / Export PDF', 'bylaw-clause-manager') . '</button>';
			}
			echo '</div><!-- #bcm-toolbar -->';
		}

		// Render tree with custom render function that respects settings
		$this->render_bylaw_tree_widget(0, 0, $group, $max_depth, $show_tooltips, $indent);

		// ===== CACHE STORE START =====
		$output = ob_get_clean();

		if ($use_cache) {
			set_transient($cache_key, $output, 12 * HOUR_IN_SECONDS);
		}

		echo '<div class="bcm-wrapper">' . $output . '</div>';
		// ===== CACHE STORE END =====
	}

	/**
	 * Render bylaw tree with widget settings.
	 *
	 * This is a modified version of bcm_render_bylaw_tree() that respects widget settings.
	 *
	 * @param int $parent_id Parent clause ID.
	 * @param int $depth Current depth level.
	 * @param string|null $group Bylaw group filter.
	 * @param int $max_depth Maximum depth to render (0 = unlimited).
	 * @param bool $show_tooltips Whether to show vote tooltips.
	 * @param int $indent Indentation per level in pixels.
	 */
	private function render_bylaw_tree_widget($parent_id = 0, $depth = 0, $group = null, $max_depth = 0, $show_tooltips = true, $indent = 20)
	{
		// Stop if max depth reached
		if ($max_depth > 0 && $depth >= $max_depth) {
			return;
		}

		$meta_query = [];

		if ($parent_id === 0) {
			$meta_query[] = [
				'relation' => 'OR',
				['key' => 'parent_clause', 'compare' => 'NOT EXISTS'],
				['key' => 'parent_clause', 'value' => '', 'compare' => '='],
				['key' => 'parent_clause', 'value' => '0', 'compare' => '=']
			];
		} else {
			$meta_query[] = ['key' => 'parent_clause', 'value' => $parent_id, 'compare' => '='];
		}

		if ($depth === 0 && $group) {
			$meta_query[] = ['key' => 'bylaw_group', 'value' => $group, 'compare' => '='];
		}

		$clauses = get_posts([
			'post_type'   => 'bylaw_clause',
			'meta_query'  => $meta_query,
			'numberposts' => -1,
		]);

		usort($clauses, function ($a, $b) {
			return bcm_title_sort_key($a->post_title) <=> bcm_title_sort_key($b->post_title);
		});

		if (!$clauses) return;

		foreach ($clauses as $clause) {
			$section      = get_post_meta($clause->ID, 'section_id', true);
			$content      = $clause->post_content;
			$parent       = get_post_meta($clause->ID, 'parent_clause', true);

			// Build vote tooltip if enabled
			$vote_marker = $show_tooltips ? bcm_generate_vote_tooltip($clause->ID) : '';

			if ((int)$clause->ID === (int)$parent) continue;

			$anchor_id = sanitize_title($section ?: $clause->ID);
			$margin    = $indent * (int)$depth;

			// Store content in data attribute for searching
			$search_content = wp_strip_all_tags($content);

			echo "\n" . '<div class="bylaw-clause" id="clause-' . esc_attr($anchor_id) . '" data-id="' . esc_attr($clause->ID) . '" data-parent="' . esc_attr($parent ?: 0) . '" data-content="' . esc_attr(strtolower($search_content)) . '" style="margin-left:' . esc_attr($margin) . 'px;">';
			echo "\n  <div class=\"bylaw-label-wrap\">";
			echo "\n    <div class=\"bylaw-label-text\">";

			// Section number rendered via data attribute + CSS ::before
			echo "\n      <span class=\"bylaw-section-id\" data-no-translation data-section=\"" . esc_attr($section) . ".\"></span>";
			$filtered_content = apply_filters('the_content', $content);
			echo wp_kses_post($filtered_content);
			if (!empty($vote_marker)) {
				echo wp_kses_post($vote_marker);
			}

			echo "\n    </div>";
			echo "\n  </div>";
			echo "\n</div>\n";

			$this->render_bylaw_tree_widget($clause->ID, $depth + 1, $group, $max_depth, $show_tooltips, $indent);
		}
	}
}
